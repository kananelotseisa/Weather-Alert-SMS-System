import fetch from 'node-fetch'; // Import node-fetch for making HTTP requests
const { exec } = require('child_process'); // Import child_process to execute shell commands

// Function to fetch weather forecast from the API
async function fetchWeatherForecast(apiKey) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=Lesotho&APPID=80527a53c90ee24c06ac4186fd09d123`;
    const response = await fetch(url);
    const data = await response.json();
    return data;
}

// Function to check if the weather forecast indicates critical conditions
async function isCriticalWeather() {
    const forecast = await fetchWeatherForecast();
    // Extract weather data from the forecast
    const weather = forecast.weather[0];
    const temperature = forecast.main.temp;
    const description = weather.description;

    // Check for critical weather conditions
    if (description.includes('extreme rain') || description.includes('snow') || description.includes('thunderstorm')) {
        console.log('Critical weather condition found:', description);
        return true;
    }

    // Check for extreme temperatures
    if (temperature < 273 || temperature > 303) { // Convert temperature from Kelvin to Celsius
        console.log('Critical weather condition found: Extreme temperatures');
        return true;
    }

    // If no critical weather conditions found
    console.log('No critical weather conditions found');
    return false;
}

// Open HTML file in the default browser
function openHTMLInBrowser(isCritical) {
    exec('start admin_dashboard.html', (err, stdout, stderr) => {
        if (err) {
            console.error('Error opening HTML file:', err);
            return;
        }
        console.log('HTML file opened in browser.');
    });
}

// Check if weather is critical and open HTML in browser accordingly
isCriticalWeather().then(isCritical => {
    openHTMLInBrowser(isCritical);
}).catch(err => {
    console.error('Error fetching weather forecast:', err);
});
