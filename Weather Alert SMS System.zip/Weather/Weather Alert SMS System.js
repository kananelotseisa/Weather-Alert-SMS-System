const fetch = require('node-fetch'); // Import node-fetch for making HTTP requests

// Function to fetch weather forecast from the API
async function fetchWeatherForecast(lat, lon, cnt, apiKey) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=Lesotho&APPID=80527a53c90ee24c06ac4186fd09d123`;
    const response = await fetch(url);
    const data = await response.json();
    return data;
}

// Function to check if the weather forecast indicates critical conditions
function isCriticalWeather(forecast) {
    // Extract weather data from the forecast
    const weather = forecast.weather[0];
    const temperature = forecast.main.temp;
    const description = weather.description;

    // Check for critical weather conditions
    if (description.includes('extreme rain') || description.includes('snow') || description.includes('thunderstorm')) {
        return true; // Critical weather condition found
    }

    // Check for extreme temperatures
    if (temperature < 273 || temperature > 303) { // Convert temperature from Kelvin to Celsius
        return true; // Critical weather condition found
    }

    // If no critical weather conditions found
    return false;
}


// Function to send alert SMS
function sendAlertSMS(message) {
    // Your logic to send SMS alerts
}

// Main function to continuously check weather forecast
async function checkWeatherForecast() {
    const lat = 28.25; // Coordinates for Lesotho
    const lon = -29.5;
    const cnt = 1;  //weather forecast is checked after 1 day
    const apiKey = '80527a53c90ee24c06ac4186fd09d123';

    while (true) {
        const currentDate = new Date();
        let forecastDate = new Date(currentDate);
        forecastDate.setDate(currentDate.getDate() + 3);

        if (forecastDate.getDay() > 7) {
            forecastDate.setDate(forecastDate.getDate() - 7);
        }

        const weatherForecast = await fetchWeatherForecast(lat, lon, cnt, apiKey);
        const criticalWeatherForecast = isCriticalWeather(weatherForecast);

        if (criticalWeatherForecast) {
            let isAlertSentForSubsequentDays = false;
            const criticalDays = [];

            for (let i = 0; i <= 2; i++) {
                const currentDay = new Date(currentDate);
                currentDay.setDate(currentDate.getDate() + i);
                const currentDayWeatherForecast = await fetchWeatherForecast(lat, lon, cnt, apiKey);
                if (isCriticalWeather(currentDayWeatherForecast)) {
                    criticalDays.push(currentDay.toDateString());
                    if (i > 0) {
                        isAlertSentForSubsequentDays = true;
                    }
                }
            }

            if (criticalDays.length > 0) {
                const message = `Critical weather alert for ${criticalDays.join(', ')}`;
                sendAlertSMS(message);
            } else if (!isAlertSentForSubsequentDays) {
                sendAlertSMS(`Critical weather alert for ${forecastDate.toDateString()}`);
            }
        }

        // Update current date for the next iteration
        currentDate.setDate(currentDate.getDate() + 1);
        await new Promise(resolve => setTimeout(resolve, 86400000)); // Wait for one day (86400000 milliseconds)
    }
}

// Call the main function to start checking weather forecast
checkWeatherForecast();
